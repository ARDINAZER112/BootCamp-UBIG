// import { useState } from 'react'
// import './App.css'
import { Route, Routes, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import ValidationCreate from './pages/ValidationCreate'
import Cars from './pages/Cars'
import CarDetail from './pages/CarDetail'

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/validationcreate" element={<ValidationCreate />} />
          <Route path="/cars" element={<Cars />} />
          <Route path="/cardetail" element={<CarDetail />} />
          <Route path='*' element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </AuthProvider>
  )
}