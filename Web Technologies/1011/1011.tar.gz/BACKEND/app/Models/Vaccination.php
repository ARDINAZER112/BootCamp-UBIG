<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vaccination extends Model
{
    protected $table = 'vaccinations';
    public $timestamps = false;

    public function doctor()
    {
        return $this->belongsTo(doctor::class, 'doctor_id');
    }

    public function spot()
    {
        return $this->belongsTo(spot::class);
    }

    public function vaccine()
    {
        return $this->belongTo(vaccine::class);
    }

}
