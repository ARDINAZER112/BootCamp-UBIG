<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Laravel\Sanctum\Sanctum;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Tabel personal_access_tokens sudah ada di db-dump.sql,
        // jadi migrasi bawaan Sanctum tidak perlu dijalankan.
        Sanctum::ignoreMigrations();
    }

    public function boot(): void
    {
        //
    }
}
